﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ICuravel
{
    void CurarVida(int quantidadeDeCura);
}
